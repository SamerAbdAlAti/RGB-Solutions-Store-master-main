enum RouteType { category, collection, product, unclickable }

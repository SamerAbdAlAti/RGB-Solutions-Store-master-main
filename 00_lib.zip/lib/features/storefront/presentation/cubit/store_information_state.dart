part of 'store_information_cubit.dart';

@freezed
class StoreInformationState with _$StoreInformationState {
  const factory StoreInformationState.initial() = _Initial;
}

part of 'storefront_bloc.dart';

@freezed
class StorefrontEvent with _$StorefrontEvent {
  const factory StorefrontEvent.started() = _Started;
  
}
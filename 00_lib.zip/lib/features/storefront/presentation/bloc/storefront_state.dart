part of 'storefront_bloc.dart';

@freezed
class StorefrontState with _$StorefrontState {
  const factory StorefrontState.initial() = _Initial;
}


import 'package:flutter/material.dart';

class DekstopDeliveryPrice extends StatefulWidget {
  const DekstopDeliveryPrice({super.key});

  @override
  State<DekstopDeliveryPrice> createState() => _DekstopDeliveryPriceState();
}

class _DekstopDeliveryPriceState extends State<DekstopDeliveryPrice> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
